import base64

addon_name   = base64.b64decode('W0NPTE9SIHdoaXRlXUdlbWluaWlbL0NPTE9SXQ==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLkdlbWluaWk=')

host         = base64.b64decode('aHR0cDovL2lwdHZnZW1pbmkuZGRucy5uZXQ=')
port         = base64.b64decode('ODEyNw==')