import base64

addon_name   = base64.b64decode('W0NPTE9SIHdoaXRlXUdlbWluaSBJUFRWWy9DT0xPUl0=')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLkdlbWluaUlQVFY=')

host         = base64.b64decode('aHR0cDovL2lwdHZnZW1pbmkuZGRucy5uZXQ=')
port         = base64.b64decode('ODEyNw==')